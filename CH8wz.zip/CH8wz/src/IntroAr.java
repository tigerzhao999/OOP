
public class IntroAr {
    public static void main(String[] args) {
        int size = 5;
        int[] named = {1, 2, 3, 4, 5,};
        int sum = 0;
        for(int i : named) {

        }

    }
}

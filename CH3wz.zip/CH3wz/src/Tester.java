
public class Tester {

	public static void main(String[] args) {
		BankAccount abc = new BankAccount();
		abc.deposit(5000);
		abc.widthdraw(1000000);
		abc.showBalance();
		abc.widthdraw(1003);
		abc.showBalance();
		
		
		

	}

}

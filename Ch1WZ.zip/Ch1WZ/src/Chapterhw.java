
public class Chapterhw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("+--------+");
		System.out.println("| Wesley |");
		System.out.println("+--------+");
		//als;dkfj;alskjdflaksjd;flkasj;lfkjas;ldkfj
	}
}





public class Chapter2WZhw {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
		String MFW = "hello,nina";
		System.out.println(MFW);

	}

}


public class PrimeNum {

	int in = 12;
	int x = 0;
	int y = 1;
	

		public void listPrime(){
			for(int i = 1; i > 0; i++){ //make an infinite loop
			for(int n = 1; n < i; n++ ){
			if(i % n == 0){
				
			}
			else{
				System.out.println(i);
			}
		}			
		}
	}
}

/*6.1 a Quarters > 0 Needs () 
 * b.
 * c. else does not conditon
 * d. the things in between {}
 * e. cannot do ( X <= Y <= Z)
 * f. syntax
 * g. cannot compare ("N") and "NO"
 * h. int wil never be null
 * i. two if statements
 */	
/*6.5
 * Tom
 * Tom
 * Churchill
 * Car Manufacturer
 * Harry
 * C++
 * Tom
 * Car
 * bar
 * 101
 * 1.01	
 */
/*
 *6.8 true 
 * 
 * 
 */

/* 6.10
 * a. x <= 0 || y <= 0
 * b. x == 0 && y == 0
 * c. !country.equals("US") || state.equals("HI") || state.equals("AK")
 * d. x % 4 == 0 && x % 100 == 0 && x % 400 == 0
 */

/*6.13
 *  r == s compares references
 *  r.equals(s) compares values 
 */



public class Homework {
	public void calc(){
	
	int x = 0;
	if (x >= 0) 
		System.out.println("asdf");
			
	}
}

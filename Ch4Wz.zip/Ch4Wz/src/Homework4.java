/* 4.3 no parentheses around 2 * a 
 * 4.4 byte f = 127;
		f++
		Gives you -128 which is wrong
 * 4.6 a floating point number has 15 significant digits while int gives you a number without decimals
 * 4.8 (2) is an int
       (2.0) is a double 
       ('2') is a character 
       ("2") is a string
       ("2.0") is also a string
* 4.11 A True
       B False
       C ?????
       
 * 4.16 
 *  
 */

		
public class Homework4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//float f = 120;
		//f = 25 + 30;
		//f = f * 100;
		//System.out.println ('s');
		double x = 2.5;
		double y = -1.5;
		int m = 18;
		int n = 4;
		String s = "Hello";
		String t = "World";
		System.out.println(x + n); 
		

		
		
		 
		
		
		

	}

}

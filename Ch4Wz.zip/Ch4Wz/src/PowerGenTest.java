
public class PowerGenTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PowerGenerator myPow = new PowerGenerator(10);
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());
		System.out.println(myPow.next());

	}

}

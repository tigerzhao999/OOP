
public class Bullseye {

}
